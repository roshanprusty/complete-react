import Form from "./Component/Form";

function App(){

  return(<>
   
    <Form />
   
  </>)

}
export default App;